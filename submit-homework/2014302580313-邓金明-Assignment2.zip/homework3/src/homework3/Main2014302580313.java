package homework3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Main2014302580313 {
	static Document document;
	static String name="无此条目";
	static String email="无此条目";
	static String tel="无此条目";
	static String briefInfo="无此条目";
	static String researchDirect="无此条目";
	public static void main(String[] args){
		try {
			document = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping").get();  //连接获取网页源码
			name = document.select("h3[class=title]").get(0).text();									   //得到教师名字
			String otherInfo = document.select("div[class=details col-md-10 col-sm-9 col-xs-7]")
					.select("p").get(0).text();
			Pattern telNum = Pattern.compile("[0-9]{11}");   //11位电话号码
			Pattern mail = Pattern.compile("([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)*"
					+ "@([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)+[\\.][A-Za-z]{2,3}([\\.][A-Za-z]{2})?");   //提取邮箱的正则表达式
			
			//提取电话
			Matcher matcher = telNum.matcher(otherInfo);
			if (matcher.find()) {
				tel = matcher.group();
			}
			
			//提取邮箱
			matcher = mail.matcher(otherInfo);
			if (matcher.find()) {
				email = matcher.group();
			}
			
			//获取研究方向及简介
			briefInfo = otherInfo.split(" ")[0]+otherInfo.split(" ")[1]+otherInfo.split(" ")[2];
			researchDirect = otherInfo.split(" ")[3]+otherInfo.split(" ")[4];
			
			File f = new File("./info.txt");
			FileOutputStream fos = new FileOutputStream(f);
			name = "姓名："+name+"\n";
			briefInfo = "简介："+briefInfo+"\n";
			email = "邮箱："+email+"\n";
			tel = "电话："+tel+"\n";
			researchDirect = researchDirect+"\n";
			fos.write(name.getBytes());
			fos.write(briefInfo.getBytes());
			fos.write(researchDirect.getBytes());
			fos.write(tel.getBytes());
			fos.write(email.getBytes());
			fos.flush();
			fos.close();
			
			
			
		} catch (IOException e) {
			System.out.println("------------Connect erro-----------");
			e.printStackTrace();
		}
		
	}
}
